package food.junkfood;
import food.Food;
public class Junkfood extends Food{
  public Junkfood(){

  }
}
