package food.junkfood;
public class Hamburger extends Junkfood{
  public Hamburger(){
    setColor("tasty");
  }
}
