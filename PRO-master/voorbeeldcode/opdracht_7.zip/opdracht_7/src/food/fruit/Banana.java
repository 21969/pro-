package food.fruit;
public class Banana extends Fruit {
  public Banana(){
    setColor("yellow");
  }
}
