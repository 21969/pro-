package food.fruit;
import food.Food;

public class Fruit extends Food{
  public Fruit(){
  }
}
