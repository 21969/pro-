package food.vegetables;
import food.Food;
public class Vegetables extends Food{
  public Vegetables(){

  }
}
