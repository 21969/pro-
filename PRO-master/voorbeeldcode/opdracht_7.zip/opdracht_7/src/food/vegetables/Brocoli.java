package food.vegetables;
public class Brocoli extends Vegetables{
  public Brocoli(){
    setColor("Beautiful");
  }
}
